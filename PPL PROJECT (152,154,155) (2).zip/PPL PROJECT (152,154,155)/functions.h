#define SCALE 31

int compareEqual(number No1, number No2);

void decimalEqual(number *No1, number *No2);

number *add(number *No1, number *No2);

number *sub(number *No1, number *No2);

number *mult(number *No1, number *No2);

number *division(number *No1, number *No2);

number *modulus(number *No1, number *No2);

